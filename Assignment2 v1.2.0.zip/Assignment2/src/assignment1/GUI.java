/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1;

import java.awt.BorderLayout;
import java.awt.Frame;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author William
 */
public class GUI {
    
  public void confirmationPanel(){
    JFrame frame = new JFrame();
    JPanel panel = new JPanel(null);
    JButton okButton = new JButton("OK");
    JLabel confirmationLabel = new JLabel("What is your name?");
          
    frame.setSize(400, 350);
    frame.setResizable(false);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    frame.add(panel);
    
    panel.add(confirmationLabel);
    confirmationLabel.setBounds(140,10,300,20);
    
    panel.add(okButton);
    okButton.setBounds(155,195,80,30);
    
    frame.setVisible(true);
    
}
    
}

