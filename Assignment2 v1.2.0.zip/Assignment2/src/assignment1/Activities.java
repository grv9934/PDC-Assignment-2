/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1;

/**
 *
 * @author William Maxwell
 */
public class Activities {

    //activity variables
    private User user;
    private Pet pet;

    //constructor for activity object
    public Activities(User user, Pet pet) {
        this.user = user;
        this.pet = pet;
    }

    //method to feed pet
    public boolean feedPet() {
        boolean isHungry = checkHunger(getPet());

        if (isHungry == true && getUser().getFoodAmount() >= 1) {
            pet.setPetHunger(pet.getPetHunger() + 10);
            pet.setPetEnergy(pet.getPetEnergy() + 10);
            user.setFoodAmount(user.getFoodAmount() - 10);
            return true;
        }

        return false;
    }

    //method to check pet hunger
    public boolean checkHunger(Pet pet) {
        
        //if pet hunger is less than 100, return true
        if (pet.getPetHunger() < 100) {
            return true;
        }

        return false;
    }
    
    //method to exercise pet
    public boolean exercisePet() {
        //if pet energy is greater or equal than 10, decrease pet hunger and energy by 10.
        if (getPet().getPetEnergy() >= 10) {
            pet.setPetHunger(pet.getPetHunger() - 10);
            pet.setPetEnergy(pet.getPetEnergy() - 10);
            return true;
        }

        return false;
    }

    /**
     * @return the user
     */
    public User getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     * @return the pet
     */
    public Pet getPet() {
        return pet;
    }

    /**
     * @param pet the pet to set
     */
    public void setPet(Pet pet) {
        this.pet = pet;
    }
}
