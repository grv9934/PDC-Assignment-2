/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1;

/**
 *
 * @author William Maxwell
 */
public abstract class Pet {
    //pet variables
    private String petName;
    private int petID;
    private int petHunger;
    private int petEnergy;
    
    //constructor for pet objects
    public Pet(String name, int id){
     this.petName = name;
     this.petID = id;
     this.petHunger = 100;
     this.petEnergy = 100;
    }

    /**
     * @return the petName
     */
    public String getPetName() {
        return petName;
    }

    /**
     * @param petName the petName to set
     */
    public void setPetName(String petName) {
        this.petName = petName;
    }

    /**
     * @return the petID
     */
    public int getPetID() {
        return petID;
    }

    /**
     * @param petID the petID to set
     */
    public void setPetID(int petID) {
        this.petID = petID;
    }

    /**
     * @return the petHunger
     */
    public int getPetHunger() {
        return petHunger;
    }

    /**
     * @param petHunger the petHunger to set
     */
    public void setPetHunger(int petHunger) {
        this.petHunger = petHunger;
    }

    /**
     * @return the petEnergy
     */
    public int getPetEnergy() {
        return petEnergy;
    }

    /**
     * @param petEnergy the petEnergy to set
     */
    public void setPetEnergy(int petEnergy) {
        this.petEnergy = petEnergy;
    }
    
    
}
