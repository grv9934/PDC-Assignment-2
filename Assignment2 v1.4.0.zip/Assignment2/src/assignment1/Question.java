/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1;

import java.text.DecimalFormat;
import java.util.Random;

/**
 *
 * @author William Maxwell
 */
public class Question {
    //question variables
    private int number1;
    private int number2;
    private double answer;
    
    //constructor for question object
    public Question() {
        this.number1 = generateNumber(100);
        this.number2 = generateNumber(100);
    }
    
    //generate a new number for equations
    public int generateNumber(int range) {
        return (new Random()).nextInt(range);
    }
    
    //generate question method
    public String generateQuestion() {
        String operation = "";
        
        //generate a number between 1 and 4 which signifies which operation to use
        switch (this.generateNumber(4)) {
            case 0:
                operation = "+";
                this.setAnswer(getNumber1() + getNumber2());
                break;
            case 1:
                operation = "-";
                this.setAnswer(getNumber1() - getNumber2());
                break;
            case 2:
                operation = "*";
                this.setAnswer(getNumber1() * getNumber2());
                break;
            case 3:
                operation = "/";
                //Keep assigning a new random number to num2 if num2 is 0.
                while (getNumber2() == 0) {
                    setNumber2(this.generateNumber(100));
                }
                // In java, the result of an integer divided by an integer is still an integer.
                this.setAnswer(1d * getNumber1() / getNumber2());
                // Hence, we first let num1 times 1.0 to make num1 become a double type number.
                break;
            default:
                break;
        }
        
        //put together question
        operation = getNumber1() + operation + getNumber2() + "?";
        return operation;
    }
    
    //method to check answer of question
    public boolean checkAnswer(String userAnswer){
        //convert user answer from string to double
        Double uAnswer = Double.parseDouble(userAnswer);
        
        //convert answer to 3 decimal places
        DecimalFormat df = new DecimalFormat("#.###");
        String formattedValue = df.format(getAnswer());
        setAnswer(Double.parseDouble(formattedValue));
        
        //compare answer with user answer and return result
        return Math.abs(getAnswer() - uAnswer) < 0.0001;
    }

    /**
     * @return the number1
     */
    public int getNumber1() {
        return number1;
    }

    /**
     * @param number1 the number1 to set
     */
    public void setNumber1(int number1) {
        this.number1 = number1;
    }

    /**
     * @return the number2
     */
    public int getNumber2() {
        return number2;
    }

    /**
     * @param number2 the number2 to set
     */
    public void setNumber2(int number2) {
        this.number2 = number2;
    }

    /**
     * @return the answer
     */
    public double getAnswer() {
        return answer;
    }

    /**
     * @param answer the answer to set
     */
    public void setAnswer(double answer) {
        this.answer = answer;
    }
    
}
