/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1;

import java.io.IOException;
import java.util.HashSet;
import java.util.Scanner;

/**
 *
 * @author William Maxwell
 */
public class Game {

    public static void main(String[] args) throws IOException {
        //initialize starting variables               
        Scanner scan = new Scanner(System.in);
        String userInput = "";       
        HashSet<Dog> pets = new HashSet();
        pets.add(new Dog("Max", 1, "Golden Labrador", "Brown", "Gold"));
        pets.add(new Dog("Daisy", 2, "Pug", "Blue", "Grey"));
        pets.add(new Dog("Butch", 3, "Mastiff", "Brown", "Black"));
        pets.add(new Dog("Selene", 4, "Husky", "Blue", "Grey/White"));
        pets.add(new Dog("Benjamine", 5, "Chihuahua", "Black", "Brown"));
        
        //GUI to get username and create user
        GUIGetUsername getUserName = new GUIGetUsername();
        getUserName.initializePanel();

        while (getUserName.initFrame.isVisible()) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        
        String userName = getUserName.returnUsername();
        User user = new User(userName, null);

        //GUI to get pet and assign user their pet
        GUIGetPet getPet = new GUIGetPet(userName);
        getPet.initializePanel();

        while (getPet.initFrame.isVisible()) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        
        int petID = getPet.returnPetID();
        switch (petID) {
                case 1:
                    for (Dog dog : pets) {
                        if (dog.getPetID() == 1) {
                            user.setUserPet(dog);
                        }
                    }
                    break;

                case 2:
                    for (Dog dog : pets) {
                        if (dog.getPetID() == 2) {
                            user.setUserPet(dog);
                        }
                    }
                    break;
                case 3:
                    for (Dog dog : pets) {
                        if (dog.getPetID() == 3) {
                            user.setUserPet(dog);
                        }
                    }
                    break;
                case 4:
                    for (Dog dog : pets) {
                        if (dog.getPetID() == 4) {
                            user.setUserPet(dog);
                        }
                    }
                    break;
                case 5:
                    for (Dog dog : pets) {
                        if (dog.getPetID() == 5) {
                            user.setUserPet(dog);
                        }
                    }
                    break;
                default:
        }        
                    

    GUIMainGame mainGame = new GUIMainGame(user, user.getUserPet());
    mainGame.initializePanel();
        
        
        
        

//        //ask user what their name is and create a user object
//        boolean confirmName = false;
//        String userName = "";
//        
//        //while variable confirmName is false, keep asking user what their name is
//        while (confirmName == false) {
//            System.out.println("What is your name?");
//            userName = scan.nextLine();         
//            System.out.println("Are you sure you want your user to be named: " + userName + "? (Y/y for yes, N/n for no).");
//            userInput = scan.nextLine();
//            
//            //if user says yes, set confirmName to true and break the loop
//            switch (userInput) {
//                case ("y"):
//                case ("Y"):
//                    confirmName = true;
//                    break;
//            //if user says no, keep looping
//                case ("n"):
//                case ("N"):
//                    confirmName = false;
//                    break;
//                default:
//                    System.out.println("Invalid input. Please enter Y/y for yes, or N/n for no.");
//                    break;
//            }
//        }
//
//        User user = new User(userName, null);
//
//        //varibles to check if user exists in the user file
//        ReadWrite userFile = new ReadWrite(user);
//        boolean userExists = userFile.checkUser();
//        boolean selectedPet = false;
//
//        //if user exists in the user file, load the user, else create a new user and ask them what pet they would like
//        if (userExists == true) {
//            userInput = userFile.loadUser();
//            System.out.println("\nWelcome back " + user.getUserName());
//        } else {
//            System.out.println("User added.");
//
//            System.out.println("\nWhich pet would you like " + user.getUserName() + "? (Please input a pet ID):");
//            for (Dog dog : pets) {
//                System.out.println(dog);
//            }
//            userInput = scan.nextLine();
//        }
//
//        //assign new user their pet
//        while (selectedPet == false) {
//            switch (userInput) {
//                case "1":
//                    for (Dog dog : pets) {
//                        if (dog.getPetID() == 1) {
//                            user.setUserPet(dog);
//                        }
//                    }
//                    selectedPet = true;
//                    break;
//
//                case "2":
//                    for (Dog dog : pets) {
//                        if (dog.getPetID() == 2) {
//                            user.setUserPet(dog);
//                        }
//                    }
//                    selectedPet = true;
//                    break;
//                case "3":
//                    for (Dog dog : pets) {
//                        if (dog.getPetID() == 3) {
//                            user.setUserPet(dog);
//                        }
//                        selectedPet = true;
//                    }
//                    break;
//                case "4":
//                    for (Dog dog : pets) {
//                        if (dog.getPetID() == 4) {
//                            user.setUserPet(dog);
//                        }
//                        selectedPet = true;
//                    }
//                    break;
//                case "5":
//                    for (Dog dog : pets) {
//                        if (dog.getPetID() == 5) {
//                            user.setUserPet(dog);
//                        }
//                        selectedPet = true;
//                    }
//                    break;
//                default:
//                    System.out.println("Invalid pet ID. Please choose again.");
//                    userInput = scan.nextLine();
//            }
//        }
//
//        System.out.println("\nYour pet is a " + user.getUserPet().getSpecies() + " named " + user.getUserPet().getPetName());
//
//        //main game loop
//        while (!(userInput.trim().equals("7"))) {
//            System.out.println("\nWhat would you like to do?"
//                    + "\n1. Check pet status. "
//                    + "\n2. Check user resources."
//                    + "\n3. Feed pet. "
//                    + "\n4. Exercise pet. "
//                    + "\n5. Buy food. "
//                    + "\n6. Earn money. "
//                    + "\n7. Exit game.");
//
//            userInput = scan.nextLine().trim();
//            Activities activities = new Activities(user, user.getUserPet());
//
//            //game code
//            switch (userInput) {
//                //if user pressed 1, get pet details
//                case ("1"):
//                    System.out.println("\nPet name: " + user.getUserPet().getPetName()
//                            + "\nHunger: " + user.getUserPet().getPetHunger()
//                            + "\nEnergy: " + user.getUserPet().getPetEnergy());
//                    break;
//                //if user pressed 2, get user details
//                case ("2"):
//                    System.out.println("Your money: " + user.getUserMoney()
//                            + "\nYour food amount: " + user.getFoodAmount());
//                    break;
//                //if user pressed 3, feed pet
//                case ("3"):
//                    boolean isFed = activities.feedPet();
//                    //if pet hunger is less than 100, feed pet
//                    if (isFed == true) {
//                        System.out.println("\nYour pet has been fed.");
//                    } else if (user.getFoodAmount() == 0) {
//                        System.out.println("\nYou do not have enough food to feed your pet.");
//                    } else {
//                        System.out.println("\nYour pet is already full.");
//                    }
//
//                    System.out.println("Your pet's hunger is currently: " + user.getUserPet().getPetHunger()
//                            + "\nYour food amount is currently: " + user.getFoodAmount());
//                    break;
//                //if user pressed 4, exercise pet
//                case ("4"):
//                    boolean enoughEnergy = activities.exercisePet();
//                    //if pet has energy > 0, exercise pet
//                    if (enoughEnergy == true) {
//                        System.out.println("\nYou took your pet for a walk.");
//                    } else {
//                        System.out.println("\nYour pet is too tired for exercise. Feed them to restore their energy.");
//                    }
//
//                    System.out.println("Your pet's energy levels are currently: " + user.getUserPet().getPetEnergy());
//                    break;
//                //if user pressed 5, buy more food
//                case ("5"):
//                    PetShop shop = new PetShop(user);
//                    boolean boughtFood = shop.buyFood();
//
//                    if (boughtFood == true) {
//                        System.out.println("\nSuccessfully bought more food.");
//                    } else {
//                        System.out.println("\nYou don't have enough money to buy more food.");
//                    }
//
//                    System.out.println("\nYour money: " + user.getUserMoney()
//                            + "\nYour food amount: " + user.getFoodAmount());
//                    break;
//                //if user pressed 6, enable user to earn money by answering math questions
//                case ("6"):
//                        try {
//                    Work work = new Work(user);
//                    System.out.println("\nIn order to earn money, you must answer this question: "
//                            + "\nWhat is " + work.getQuestion().generateQuestion() + "\n(Round division answers to 3 decimal places)"
//                            + "\n(Answer: " + work.getQuestion().getAnswer() + ")");
//
//                    userInput = scan.nextLine();
//                    boolean correctAnswer = work.earnMoney(userInput);
//
//                    if (correctAnswer == true) {
//                        System.out.println("\nCorrect! You have earned $30.");
//                    } else {
//                        System.out.println("\nIncorrect! You have earned $0.");
//                    }
//                } catch (NumberFormatException e) {
//                    System.out.println("\nInput is not a valid number.");
//                }
//                break;
//                //if user pressed 7, ask the user if they want to save their profile and quit
//                case ("7"):
//                    //ask user to save their user
//                    System.out.println("\nWould you like to save your user? (Enter Y/y for yes, N/n for no).");
//                    userInput = scan.nextLine();
//                    switch (userInput) {
//                        case ("y"):
//                        case ("Y"):
//                            userFile.saveUser();
//                            System.out.println("\nYour user has been saved.");
//                            System.exit(0);
//                            break;
//                        case ("n"):
//                        case ("N"):
//                            System.out.println("\nYour user has not been saved.");
//                            System.exit(0);
//                            break;
//                        default:
//                            break;
//                    }
//                //user input error handling
//                default:
//                    System.out.println("\nInvalid input. Please try again");
    }
}
