/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author William
 */
public final class Database {

    private static final String USER_NAME = "pdc"; //your DB username
    private static final String PASSWORD = "pdc"; //your DB password
    private static final String URL = "jdbc:derby:PetDB; create=true";  //url of the DB host

    Connection conn;

    public Database() throws SQLException {
        establishConnection();
    }

    public static void main(String[] args) throws SQLException {
        Database database = new Database();
        database.createPetTable();
        database.queryPetTable();

    }

    //establish connection to the database
    public void establishConnection() throws SQLException {
        conn = DriverManager.getConnection(URL, USER_NAME, PASSWORD);

    }

    public void createPetTable() throws SQLException {
        Statement statement = conn.createStatement();

        statement.addBatch("DROP TABLE PET");
        statement.addBatch("CREATE TABLE PET (PETID INT, PETNAME VARCHAR(50), SPECIES VARCHAR(50), EYECOLOUR VARCHAR(20), FURCOLOUR VARCHAR(20))");
        statement.addBatch("INSERT INTO PET VALUES (1, 'Max', 'Golden Labrador', 'Brown', 'Gold')");
        statement.executeBatch();

    }

    public void queryPetTable() throws SQLException {
        Statement statement = conn.createStatement();
        ResultSet rs = statement.executeQuery("SELECT * FROM PET");
        while (rs.next()) {
            int petID = rs.getInt("PETID");
            String petName = rs.getString("PETNAME");
            String petSpecies = rs.getString("SPECIES");
            String eyeColour = rs.getString("EYECOLOUR");
            String furColour = rs.getString("FURCOLOUR");

            System.out.println("Pet ID: " + petID
                    + "\nName: " + petName
                    + "\nSpecies: " + petSpecies
                    + "\nEye Colour: " + eyeColour
                    + "\nFur Colour: " + furColour);
        }

    }

}
