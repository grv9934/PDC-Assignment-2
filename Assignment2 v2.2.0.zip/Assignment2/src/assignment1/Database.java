/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author William
 */
public final class Database {

    private static final String USER_NAME = "pdc"; //your DB username
    private static final String PASSWORD = "pdc"; //your DB password
    private static final String URL = "jdbc:derby:PetDB; create=true";  //url of the DB host

    Connection conn;

    public Database() throws SQLException {
        establishConnection();
    }

    public Connection getConnection() {
        return this.conn;
    }

    //establish connection to the database
    public void establishConnection() throws SQLException {
        conn = DriverManager.getConnection(URL, USER_NAME, PASSWORD);

    }

}
