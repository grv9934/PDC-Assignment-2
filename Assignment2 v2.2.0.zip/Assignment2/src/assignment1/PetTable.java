/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author William
 */
public class PetTable {
    
    private final Database database;
    private final Connection conn;
    private Statement statement;
    
    public PetTable() throws SQLException {
        database = new Database();
        conn = database.getConnection();
    }
    
    public void createPetTable() throws SQLException {
        statement = conn.createStatement();

        statement.addBatch("DROP TABLE PET");
        statement.addBatch("CREATE TABLE PET (PETID INT, PETNAME VARCHAR(50), SPECIES VARCHAR(50), EYECOLOUR VARCHAR(20), FURCOLOUR VARCHAR(20))");
        statement.addBatch("INSERT INTO PET VALUES (1, 'Max', 'Golden Labrador', 'Brown', 'Gold'),"
                + "(2, 'Daisy', 'Pug', 'Blue', 'Grey'),"
                + "(3, 'Butch', 'Mastiff', 'Brown', 'Black'),"
                + "(4, 'Selene', 'Husky', 'Blue', 'Grey/White'),"
                + "(5, 'Benjamine', 'Chihuahua', 'Black', 'Brown')");
        statement.executeBatch();

    }
    
    public void queryPetTable() throws SQLException {
        statement = conn.createStatement();
        ResultSet rs = statement.executeQuery("SELECT * FROM PET");
        while (rs.next()) {
            int petID = rs.getInt("PETID");
            String petName = rs.getString("PETNAME");
            String petSpecies = rs.getString("SPECIES");
            String eyeColour = rs.getString("EYECOLOUR");
            String furColour = rs.getString("FURCOLOUR");

            System.out.println("Pet ID: " + petID
                    + "\nName: " + petName
                    + "\nSpecies: " + petSpecies
                    + "\nEye Colour: " + eyeColour
                    + "\nFur Colour: " + furColour
                    + "\n");
        }

    }
    
    public static void main(String[] args) throws SQLException {
        PetTable petTable = new PetTable();
        
        petTable.database.establishConnection();
        petTable.createPetTable();
        petTable.queryPetTable();

    }   
    
}
