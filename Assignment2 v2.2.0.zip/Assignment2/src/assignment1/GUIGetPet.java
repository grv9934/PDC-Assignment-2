/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

/**
 *
 * @author William
 */
public class GUIGetPet extends JFrame implements ActionListener {

    JFrame initFrame = new JFrame();
    JPanel initPanel = new JPanel(null);
    String username;
    JLabel initLabel = new JLabel();
    JLabel initLabel1 = new JLabel("<html>Max (Golden labrador with brown eyes and golden fur)</html>");
    JLabel initLabel2 = new JLabel("<html>Daisy (Pug with blue eyes and grey fur)</html>");
    JLabel initLabel3 = new JLabel("<html>Butch (Mastiff with brown eyes and black fur)</html>");
    JLabel initLabel4 = new JLabel("<html>Selene (Husky with blue eyes and grey/white fur)</html>");
    JLabel initLabel5 = new JLabel("<html>Benjamine (Chihuahua with black eyes and brown fur)</html>");
    ButtonGroup options = new ButtonGroup();
    JRadioButton option1 = new JRadioButton();
    JRadioButton option2 = new JRadioButton();
    JRadioButton option3 = new JRadioButton();
    JRadioButton option4 = new JRadioButton();
    JRadioButton option5 = new JRadioButton();
    int petID = 0;

    public GUIGetPet(String username) {
        this.username = username;
    }

    public void initializePanel() {
        initFrame.setSize(450, 350);
        initFrame.setResizable(false);
        initFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        initFrame.add(initPanel);

        initPanel.add(initLabel);
        initLabel.setText("Which pet would you like " + username + "?");
        initLabel.setBounds(140, 10, 300, 30);

        options.add(option1);
        options.add(option2);
        options.add(option3);
        options.add(option4);
        options.add(option5);

        initPanel.add(initLabel1);
        initLabel1.setBounds(80, 70, 300, 30);
        initPanel.add(option1);
        option1.setBounds(50, 70, 20, 20);
        option1.addActionListener(this);

        initPanel.add(initLabel2);
        initLabel2.setBounds(80, 100, 300, 30);
        initPanel.add(option2);
        option2.setBounds(50, 100, 20, 20);
        option2.addActionListener(this);

        initPanel.add(initLabel3);
        initLabel3.setBounds(80, 130, 300, 30);
        initPanel.add(option3);
        option3.setBounds(50, 130, 20, 20);
        option3.addActionListener(this);

        initPanel.add(initLabel4);
        initLabel4.setBounds(80, 160, 300, 30);
        initPanel.add(option4);
        option4.setBounds(50, 160, 20, 20);
        option4.addActionListener(this);

        initPanel.add(initLabel5);
        initLabel5.setBounds(80, 190, 300, 30);
        initPanel.add(option5);
        option5.setBounds(50, 190, 20, 20);
        option5.addActionListener(this);

        initFrame.setVisible(true);

    }

    /**
     *
     * @param e
     */
    @Override
    public void actionPerformed(ActionEvent e) {

        Object source = e.getSource();

        if (source == option1) {
            this.petID = 1;
            initFrame.setVisible(false);
        } else if (source == option2) {
            this.petID = 2;
            initFrame.setVisible(false);
        } else if (source == option3) {
            this.petID = 3;
            initFrame.setVisible(false);
        } else if (source == option4) {
            this.petID = 4;
            initFrame.setVisible(false);
        } else if (source == option5) {
            this.petID = 5;
            initFrame.setVisible(false);
            
        }
    }

    public int returnPetID() {
        return this.petID;
    }
}
