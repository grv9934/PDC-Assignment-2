/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment2;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;

/**
 *
 * @author William
 */
public class PetTable {
    
    private Database database;
    private Connection conn;
    private Statement statement;
    
    public PetTable() throws SQLException {
        database = new Database();
        conn = database.getConnection();
    }
    
    public void createPetTable() throws SQLException {
        setStatement(getConn().createStatement());

        getStatement().addBatch("DROP TABLE PET");
        getStatement().addBatch("CREATE TABLE PET (PETID INT, PETNAME VARCHAR(50), SPECIES VARCHAR(50), EYECOLOUR VARCHAR(20), FURCOLOUR VARCHAR(20))");
        getStatement().addBatch("INSERT INTO PET VALUES (1, 'Max', 'Golden Labrador', 'Brown', 'Gold'),"
                + "(2, 'Daisy', 'Pug', 'Blue', 'Grey'),"
                + "(3, 'Butch', 'Mastiff', 'Brown', 'Black'),"
                + "(4, 'Selene', 'Husky', 'Blue', 'Grey/White'),"
                + "(5, 'Benjamine', 'Chihuahua', 'Black', 'Brown')");
        getStatement().executeBatch();

    }
    
    public void queryPetTable() throws SQLException {
        setStatement(getConn().createStatement());
        ResultSet rs = getStatement().executeQuery("SELECT * FROM PET");
        while (rs.next()) {
            int petID = rs.getInt("PETID");
            String petName = rs.getString("PETNAME");
            String petSpecies = rs.getString("SPECIES");
            String eyeColour = rs.getString("EYECOLOUR");
            String furColour = rs.getString("FURCOLOUR");

            System.out.println("Pet ID: " + petID
                    + "\nName: " + petName
                    + "\nSpecies: " + petSpecies
                    + "\nEye Colour: " + eyeColour
                    + "\nFur Colour: " + furColour
                    + "\n");
        }
    }
    
    public HashSet<Dog> returnPetTable() throws SQLException{
        
        HashSet<Dog> pets = new HashSet();
        
        setStatement(getConn().createStatement());
        ResultSet rs = getStatement().executeQuery("SELECT * FROM PET");
        while (rs.next()) {
            int petID = rs.getInt("PETID");
            String petName = rs.getString("PETNAME");
            String petSpecies = rs.getString("SPECIES");
            String eyeColour = rs.getString("EYECOLOUR");
            String furColour = rs.getString("FURCOLOUR");

            pets.add(new Dog(petName, petID, petSpecies, eyeColour, furColour));
        }
        
        return pets;       
    }
    
    public static void main(String[] args) throws SQLException {
        PetTable petTable = new PetTable();
        
        petTable.getDatabase().establishConnection();
        petTable.createPetTable();
        petTable.queryPetTable();

    }   

    /**
     * @return the database
     */
    public Database getDatabase() {
        return database;
    }

    /**
     * @param database the database to set
     */
    public void setDatabase(Database database) {
        this.database = database;
    }

    /**
     * @return the conn
     */
    public Connection getConn() {
        return conn;
    }

    /**
     * @param conn the conn to set
     */
    public void setConn(Connection conn) {
        this.conn = conn;
    }

    /**
     * @return the statement
     */
    public Statement getStatement() {
        return statement;
    }

    /**
     * @param statement the statement to set
     */
    public void setStatement(Statement statement) {
        this.statement = statement;
    }
    
}
