/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment2;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.text.DefaultCaret;

/**
 *
 * @author William
 */
public class GUIMainGame extends JFrame implements ActionListener {

    JFrame initFrame = new JFrame();
    JPanel initPanel = new JPanel(null);
    JButton button1 = new JButton("Pet status");
    JButton button2 = new JButton("User status");
    JButton button3 = new JButton("Feed pet");
    JButton button4 = new JButton("Exercise pet");
    JButton button5 = new JButton("Buy food");
    JButton button6 = new JButton("Earn money");
    JButton button7 = new JButton("Exit game");
    JTextArea textArea = new JTextArea();
    JScrollPane scrollPane = new JScrollPane(textArea);
    DefaultCaret caret = (DefaultCaret) textArea.getCaret();

    User user;
    Pet pet;
    Activities activities;
    Work work;  
    

    public GUIMainGame(User user, Pet pet) {
        this.user = user;
        this.pet = pet;
        this.activities = new Activities(this.user, this.pet);
        this.work = new Work(this.user);
    }

    public void initializePanel() {
        initFrame.setSize(600, 550);
        initFrame.setResizable(false);
        initFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        initFrame.add(initPanel);

        initPanel.add(scrollPane);
        scrollPane.setBounds(100, 50, 400, 280);
        textArea.setEditable(false);
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

        textArea.append("Welcome " + user.getUserName() + ". What would you like to do?\n");

        initPanel.add(button1);
        button1.setBounds(50, 355, 100, 50);
        button1.addActionListener(this);

        initPanel.add(button2);
        button2.setBounds(150, 355, 100, 50);
        button2.addActionListener(this);

        initPanel.add(button3);
        button3.setBounds(250, 355, 100, 50);
        button3.addActionListener(this);

        initPanel.add(button4);
        button4.setBounds(350, 355, 100, 50);
        button4.setFont(new Font("Arial", Font.BOLD, 10));
        button4.addActionListener(this);

        initPanel.add(button5);
        button5.setBounds(450, 355, 100, 50);
        button5.addActionListener(this);

        initPanel.add(button6);
        button6.setBounds(200, 410, 100, 50);
        button6.setFont(new Font("Arial", Font.BOLD, 11));
        button6.addActionListener(this);

        initPanel.add(button7);
        button7.setBounds(300, 410, 100, 50);
        button7.addActionListener(this);

        initFrame.setVisible(true);
    }

    JFrame workFrame = new JFrame();
    JPanel workPanel = new JPanel(null);
    JLabel workLabel = new JLabel();
    JTextArea userAnswer = new JTextArea();
    JButton confirmButton = new JButton("OK");

    public void workPanel() {

        workFrame.setSize(450, 250);
        workFrame.setResizable(false);
        workFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        workFrame.add(workPanel);

        workPanel.add(workLabel);
        workLabel.setBounds(38, 30, 380, 80);
        workLabel.setText("<html>" + "\nIn order to earn money, you must answer this question:  What is " + this.work.getQuestion().generateQuestion()
                + " (Round division answers to 3 decimal places)(Answer: " + this.work.getQuestion().getAnswer() + ")" + "</html>");

        workPanel.add(userAnswer);
        userAnswer.setBounds(40, 120, 350, 20);

        workPanel.add(confirmButton);
        confirmButton.setBounds(150, 150, 100, 50);
        confirmButton.addActionListener(this);

        workFrame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        Object source = e.getSource();

        if (source == button1) {
            textArea.append("\nPet name: " + pet.getPetName() + "\n"
                    + "Hunger: " + pet.getPetHunger() + "\n"
                    + "Energy: " + pet.getPetEnergy() + "\n");
        } else if (source == button2) {
            textArea.append("\nYour name: " + user.getUserName() + "\n"
                    + "Money: " + user.getUserMoney() + "\n"
                    + "Food amount: " + user.getFoodAmount() + "\n");
        } else if (source == button3) {
            boolean feedPet = activities.feedPet();

            if (feedPet == true) {
                textArea.append("\n" + pet.getPetName() + " has been fed and now has " + user.getUserPet().getPetHunger() + " hunger. (You have " + user.getFoodAmount() + " food remaining.\n");
            } else if (user.getFoodAmount() == 0) {
                textArea.append("\nYou do not have enough food! Buy more food to feed your pet.\n");
            } else {
                textArea.append("\n" + pet.getPetName() + " is already full and doesn't want to eat anymore. Take them for some exercise.\n");
            }
        } else if (source == button4) {
            boolean enoughEnergy = activities.exercisePet();

            if (enoughEnergy == true) {
                textArea.append("\nYou took " + pet.getPetName() + " for a walk. (" + pet.getPetEnergy() + " energy left)\n");
            } else {
                textArea.append("\n" + pet.getPetName() + " is too tired for a walk. Feed them some food to give them more energy.\n");
            }
        } else if (source == button5) {
            PetShop shop = new PetShop(user);
            boolean boughtFood = shop.buyFood();

            if (boughtFood == true) {
                textArea.append("\nSuccessfully bought more food (You have: " + user.getFoodAmount() + " food and $" + user.getUserMoney() + ").\n");
            } else {
                textArea.append("\nYou don't have enough money!\n");
            }
        } else if (source == button6) {
            
            this.workPanel();

        } else if (source == confirmButton) {
                             
            try {
                String userInput = userAnswer.getText();
                boolean correctAnswer = work.earnMoney(userInput);
                
                if (correctAnswer == true) {
                    textArea.append("\nCorrect! You have earned $30.\n");
                } else {
                    textArea.append("\nIncorrect! You have earned $0.\n");
                }
            } catch (NumberFormatException q) {
                textArea.append("\nInput is not a valid number.\n");
            }
            
            userAnswer.setText("");
            confirmButton.removeActionListener(this);
            workFrame.dispose();
        }
        else if(source == button7){
            System.exit(0);
        }

    }
}
