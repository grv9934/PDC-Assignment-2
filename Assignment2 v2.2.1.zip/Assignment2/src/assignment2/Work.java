/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment2;

import java.util.Scanner;

/**
 *
 * @author William Maxwell
 */
public class Work {
    
    //work variables
    private User user;
    private Question question;
    
    
    //constructor for work objects
    public Work(User user) {
        this.user = user;
        this.question = new Question();
    }
    
    //method for user to earn money
    public boolean earnMoney(String userAnswer) {
        
        //see if user's answer is correct
        boolean correctAnswer = getQuestion().checkAnswer(userAnswer);
        
        //if correct then increase the user's money by 30
        if (correctAnswer == true) {
            getUser().setUserMoney(getUser().getUserMoney() + 30);

            return true;
        }

        return false;

    }

    /**
     * @return the user
     */
    public User getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     * @return the question
     */
    public Question getQuestion() {
        return question;
    }

    /**
     * @param question the question to set
     */
    public void setQuestion(Question question) {
        this.question = question;
    }
    
    
}
