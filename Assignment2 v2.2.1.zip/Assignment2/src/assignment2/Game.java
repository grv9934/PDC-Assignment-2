/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment2;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashSet;

/**
 *
 * @author William Maxwell
 */
public class Game {

    public static void main(String[] args) throws IOException, SQLException {
        //initialize starting variables               
        PetTable petTable = new PetTable();
        HashSet<Dog> pets = petTable.returnPetTable();               

        //GUI to get username and create user
        GUIGetUsername getUserName = new GUIGetUsername();
        getUserName.initializePanel();

        while (getUserName.initFrame.isVisible()) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        String userName = getUserName.returnUsername();
        User user = new User(userName, null);

        //GUI to get pet and assign user their pet
        GUIGetPet getPet = new GUIGetPet(userName);
        getPet.initializePanel();

        while (getPet.initFrame.isVisible()) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        int petID = getPet.returnPetID();
        switch (petID) {
            case 1:
                for (Dog dog : pets) {
                    if (dog.getPetID() == 1) {
                        user.setUserPet(dog);
                    }
                }
                break;

            case 2:
                for (Dog dog : pets) {
                    if (dog.getPetID() == 2) {
                        user.setUserPet(dog);
                    }
                }
                break;
            case 3:
                for (Dog dog : pets) {
                    if (dog.getPetID() == 3) {
                        user.setUserPet(dog);
                    }
                }
                break;
            case 4:
                for (Dog dog : pets) {
                    if (dog.getPetID() == 4) {
                        user.setUserPet(dog);
                    }
                }
                break;
            case 5:
                for (Dog dog : pets) {
                    if (dog.getPetID() == 5) {
                        user.setUserPet(dog);
                    }
                }
                break;
            default:
        }

        GUIMainGame mainGame = new GUIMainGame(user, user.getUserPet());
        mainGame.initializePanel();

    }
}
