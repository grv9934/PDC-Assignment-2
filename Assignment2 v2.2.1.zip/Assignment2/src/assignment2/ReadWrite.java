/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author William Maxwell
 */
public class ReadWrite {
    
    //variables for readwrite
    private User user;
    private String fileName;
    
    //constructor for readwrite objects
    public ReadWrite(User user) {
        this.user = user;
        this.fileName = "out.txt";
    }
    
    //method to check user's name
    public boolean checkUser() throws FileNotFoundException, IOException {
        
        FileReader reader = new FileReader("out.txt");
        BufferedReader inStream = new BufferedReader(reader);

        User tempUser = this.getUser();

        String line = inStream.readLine();
        String compareUsername = tempUser.getUserName();
        
        //go through file and if a line contains the user name, set userExists as true
        boolean userExists = false;
        while (line != null) {

            if (line.contains(compareUsername)) {
                userExists = true;
                break;
            }
            line = inStream.readLine();
        }

        inStream.close();

        return userExists;

    }
    
    
    //method to save user to user file
    public void saveUser() throws FileNotFoundException, IOException {
        boolean userSaved = checkUser();
        
        //check if user is already in file, if true then skip
        if(userSaved == true){
            return;
        }
        
        FileOutputStream fos = new FileOutputStream(this.getFileName(), true);
        PrintWriter pw = new PrintWriter(fos);
        User tempUser = this.getUser();
        
        //record user name and user's pet id in the file
        pw.println(tempUser.getUserName() + " PetID: " + tempUser.getUserPet().getPetID());
        pw.close();
    }
    
    //method to load user into game
    public String loadUser() throws FileNotFoundException, IOException{
        String dogID = "";
        
        FileReader reader = new FileReader("out.txt");
        BufferedReader inStream = new BufferedReader(reader);

        User tempUser = this.getUser();

        String line = inStream.readLine();
        String compareUsername = tempUser.getUserName();
        
        //go through file and if the line contains the user's name and pet id, return the id of the pet
        while (line != null) {

            if (line.contains(compareUsername)&&line.contains("PetID: 1")) {
                dogID = "1";
            }
            else if (line.contains(compareUsername)&&line.contains("PetID: 2")) {
                dogID = "2";
            }
            else if (line.contains(compareUsername)&&line.contains("PetID: 3")) {
                dogID = "3";
            }
            else if (line.contains(compareUsername)&&line.contains("PetID: 4")) {
                dogID = "4";
            }
            else if (line.contains(compareUsername)&&line.contains("PetID: 5")) {
                dogID = "5";
            }
            
            line = inStream.readLine();
        }

        inStream.close();
        
        
        return dogID;
    }

    /**
     * @return the user
     */
    public User getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(User user) {
        this.user = user;
    }

    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    
    
}
