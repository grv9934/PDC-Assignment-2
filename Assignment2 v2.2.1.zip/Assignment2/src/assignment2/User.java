/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment2;

/**
 *
 * @author William Maxwell
 */
public class User {
    
    //user variables
    private String userName;
    private Dog userPet;
    private int userMoney;
    private int foodAmount;
    
    //constructor of user objects
    public User(String name, Dog pet){
        this.userName = name;
        this.userPet = pet;
        this.userMoney = 0;
        this.foodAmount = 0;
    }

    /**
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * @return the userPet
     */
    public Dog getUserPet() {
        return userPet;
    }

    /**
     * @param userPet the userPet to set
     */
    public void setUserPet(Dog userPet) {
        this.userPet = userPet;
    }

    /**
     * @return the userMoney
     */
    public int getUserMoney() {
        return userMoney;
    }

    /**
     * @param userMoney the userMoney to set
     */
    public void setUserMoney(int userMoney) {
        this.userMoney = userMoney;
    }

    /**
     * @return the foodAmount
     */
    public int getFoodAmount() {
        return foodAmount;
    }

    /**
     * @param foodAmount the foodAmount to set
     */
    public void setFoodAmount(int foodAmount) {
        this.foodAmount = foodAmount;
    }
    
    
    
}
