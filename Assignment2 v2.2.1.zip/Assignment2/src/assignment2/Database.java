/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author William
 */
public final class Database {

    private static String USER_NAME = "pdc"; //your DB username
    private static String PASSWORD = "pdc"; //your DB password
    private static String URL = "jdbc:derby:PetDB; create=true";  //url of the DB host

    private Connection conn;

    public Database() throws SQLException {
        establishConnection();
    }

    public Connection getConnection() {
        return this.getConn();
    }

    //establish connection to the database
    public void establishConnection() throws SQLException {
        setConn(DriverManager.getConnection(getURL(), getUSER_NAME(), getPASSWORD()));

    }

    /**
     * @return the USER_NAME
     */
    public static String getUSER_NAME() {
        return USER_NAME;
    }

    /**
     * @param aUSER_NAME the USER_NAME to set
     */
    public static void setUSER_NAME(String aUSER_NAME) {
        USER_NAME = aUSER_NAME;
    }

    /**
     * @return the PASSWORD
     */
    public static String getPASSWORD() {
        return PASSWORD;
    }

    /**
     * @param aPASSWORD the PASSWORD to set
     */
    public static void setPASSWORD(String aPASSWORD) {
        PASSWORD = aPASSWORD;
    }

    /**
     * @return the URL
     */
    public static String getURL() {
        return URL;
    }

    /**
     * @param aURL the URL to set
     */
    public static void setURL(String aURL) {
        URL = aURL;
    }

    /**
     * @return the conn
     */
    public Connection getConn() {
        return conn;
    }

    /**
     * @param conn the conn to set
     */
    public void setConn(Connection conn) {
        this.conn = conn;
    }

}
