/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author William
 */
public class GUIGetUsername extends JFrame implements ActionListener {
    
    //variables for the username input screen
    JFrame initFrame = new JFrame();
    JPanel initPanel = new JPanel(null);
    JLabel initLabel = new JLabel("What is your name?");
    JTextField initTextbox = new JTextField();
    JButton okButton = new JButton("OK");
    
    String username = "";

    public void initializePanel() {
        initFrame.setSize(400, 350);
        initFrame.setResizable(false);
        initFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        initFrame.add(initPanel);

        initPanel.add(initLabel);
        initLabel.setBounds(140, 10, 300, 20);

        initPanel.add(initTextbox);
        initTextbox.setBounds(30, 50, 325, 20);

        initPanel.add(okButton);
        okButton.setBounds(155, 195, 80, 30);
        okButton.addActionListener(this);

        initFrame.setVisible(true);

    }
    
    //variables for the confirmation screen
    JFrame confirmationFrame = new JFrame();
    JPanel confirmationPanel = new JPanel(null);
    JLabel confirmationLabel = new JLabel();
    JButton yesButton = new JButton("Yes");
    JButton noButton = new JButton("No");
    
    public void confirmUsernamePanel() {

        confirmationFrame.setSize(400, 200);
        confirmationFrame.setResizable(false);
        confirmationFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        confirmationFrame.add(confirmationPanel);

        confirmationPanel.add(confirmationLabel);
        confirmationLabel.setText("<html>Are you sure you want " + this.username + " as your username?</html>");
        confirmationLabel.setBounds(70, 10, 280, 80);

        confirmationPanel.add(yesButton);
        yesButton.setBounds(70, 80, 80, 30);
        yesButton.addActionListener(this);

        confirmationPanel.add(noButton);
        noButton.setBounds(240, 80, 80, 30);
        noButton.addActionListener(this);        

        confirmationFrame.setVisible(true);
    }

    /**
     *
     * @param e
     */
    @Override
    public void actionPerformed(ActionEvent e) {

        Object source = e.getSource();

        if (source == okButton) {
            this.username = initTextbox.getText();
            this.confirmUsernamePanel();

        } else if (source == yesButton) {
            confirmationFrame.setVisible(false);
            initFrame.setVisible(false);
        }
        else if(source == noButton){
            confirmationFrame.setVisible(false);
            initTextbox.setText("");
        }
    }
    
    public String returnUsername(){
        
        return this.username;
    }
}
