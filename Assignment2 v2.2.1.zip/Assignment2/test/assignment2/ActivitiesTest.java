/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package assignment2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author William
 */
public class ActivitiesTest {
    
    public ActivitiesTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of feedPet method, of class Activities.
     */
    @Test
    public void testFeedPet() {
        System.out.println("feed pet method when pet has full hunger");
        Dog dog = new Dog("Max", 1, "Golden Labrador", "Brown", "Gold");
        User user = new User("test", dog);
        Activities activities = new Activities(user, dog);
        boolean expResult = false;
        boolean result = activities.feedPet();
        assertEquals(expResult, result);
    }
    
    /**
     * Test of feedPet method, of class Activities.
     */
    @Test
    public void testFeedPet2() {
        System.out.println("feed pet method when pet has no hunger AND user has food");
        Dog dog = new Dog("Max", 1, "Golden Labrador", "Brown", "Gold");
        User user = new User("test", dog);
        Activities activities = new Activities(user, dog);
        dog.setPetHunger(0);
        user.setFoodAmount(5);
        boolean expResult = true;
        boolean result = activities.feedPet();
        assertEquals(expResult, result);
    }

    /**
     * Test of exercisePet method, of class Activities.
     */
    @Test
    public void testExercisePet() {
        System.out.println("excercise pet method when pet has energy");
        Dog dog = new Dog("Max", 1, "Golden Labrador", "Brown", "Gold");
        User user = new User("test", dog);
        Activities activities = new Activities(user, dog);
        dog.setPetEnergy(100);
        boolean expResult = true;
        boolean result = activities.exercisePet();
        assertEquals(expResult, result);
    }
    
    /**
     * Test of exercisePet method, of class Activities.
     */
    @Test
    public void testExercisePet2() {
        System.out.println("excercise pet method when pet has no energy");
        Dog dog = new Dog("Max", 1, "Golden Labrador", "Brown", "Gold");
        User user = new User("test", dog);
        Activities activities = new Activities(user, dog);
        dog.setPetEnergy(0);
        boolean expResult = false;
        boolean result = activities.exercisePet();
        assertEquals(expResult, result);
    }
    
}
