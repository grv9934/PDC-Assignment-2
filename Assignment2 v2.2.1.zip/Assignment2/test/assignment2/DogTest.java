/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package assignment2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author William
 */
public class DogTest {
    
    public DogTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getSpecies method, of class Dog.
     */
    @Test
    public void testGetSpecies() {
        System.out.println("get species method to return species of pet");
        Dog instance = new Dog("Max", 1, "Golden Labrador", "Brown", "Gold");
        String expResult = "Golden Labrador";
        String result = instance.getSpecies();
        assertEquals(expResult, result);
    }

    /**
     * Test of getEyeColour method, of class Dog.
     */
    @Test
    public void testGetEyeColour() {
        System.out.println("get eye colour method to return pet eye colour");
        Dog instance = new Dog("Max", 1, "Golden Labrador", "Brown", "Gold");
        String expResult = "Brown";
        String result = instance.getEyeColour();
        assertEquals(expResult, result);
    }
    
    /**
     * Test of getFurColour method, of class Dog.
     */
    @Test
    public void testGetFurColour() {
        System.out.println("get fur colour method to return pet fur colour");
        Dog instance = new Dog("Max", 1, "Golden Labrador", "Brown", "Gold");
        String expResult = "Gold";
        String result = instance.getFurColour();
        assertEquals(expResult, result);
    }
    
}
