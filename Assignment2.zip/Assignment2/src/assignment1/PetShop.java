/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1;

/**
 *
 * @author William Maxwell
 */
public class PetShop {
    //petshop variables
    private User user;

    //constructor for petshop objects
    public PetShop(User user) {
        this.user = user;
    }

    //method for user to buy food
    public boolean buyFood() {
        //if user has more than $10, buy 30 food and reduce money by $10
        if (getUser().getUserMoney() >= 10) {
            user.setFoodAmount(user.getFoodAmount() + 30);
            user.setUserMoney(user.getUserMoney() - 10);

            return true;
        }

        return false;
    }

    /**
     * @return the user
     */
    public User getUser() {
        return user;
    }

    /**
     * @param user the user to set
     */
    public void setUser(User user) {
        this.user = user;
    }

}
