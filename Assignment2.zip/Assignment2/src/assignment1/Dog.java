/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1;

/**
 *
 * @author William Maxwell
 */
public class Dog extends Pet{
    
    //dog class variables
    private String species;
    private String eyeColour;
    private String furColour;
    
    //constructor for dog objects
    public Dog(String petName, int petID, String species, String eyeColour, String furColour){
     super(petName, petID);
     this.species = species;
     this.eyeColour = eyeColour;
     this.furColour = furColour;
    }
    
    //toString method to print dog object information
    @Override
    public String toString(){
        String output = "";
        
        output += "Pet ID: " + super.getPetID() +   
                ", Name: " + super.getPetName() +
                ", Species: " + this.getSpecies() +
                ", Eye Colour: " + this.getEyeColour() + 
                ", Fur Colour: " + this.getFurColour();
        
        return output;
    }

    /**
     * @return the species
     */
    public String getSpecies() {
        return species;
    }

    /**
     * @param species the species to set
     */
    public void setSpecies(String species) {
        this.species = species;
    }

    /**
     * @return the eyeColour
     */
    public String getEyeColour() {
        return eyeColour;
    }

    /**
     * @param eyeColour the eyeColour to set
     */
    public void setEyeColour(String eyeColour) {
        this.eyeColour = eyeColour;
    }

    /**
     * @return the furColour
     */
    public String getFurColour() {
        return furColour;
    }

    /**
     * @param furColour the furColour to set
     */
    public void setFurColour(String furColour) {
        this.furColour = furColour;
    }
}
